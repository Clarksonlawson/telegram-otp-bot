#Twilio Details

account_sid = 'AC67e938a23330295c470433ea78af2f2b'
auth_token = 'db67a1b2b45dbe24d8c8abc68fdabf3a'
twilionumber = '+19283783461'
twiliosmsnumber = '+19283783461'

#FC Bot
API_TOKEN = "5814765141:AAEgvs5WLC4tq5NuMMHT_o7SZy1rEbJs9zU"

#Host URL
callurl = 'https://1b41-102-90-42-244.eu.ngrok.io'
twiliosmsurl = 'https://1b41-102-90-42-244.eu.ngrok.io/sms'









