import sqlite3
from dbase import *

def main():
    adminid = input("5832961437")
    check = check_admin(5832961437)
    if check == True:
      print("Admin already exists")
    else:
        print("admin not found!")
        try:
            create_admin(5832961437)
            create_user_lifetime(5832961437)
        except:
            print('something went wrong')
        else:
         print('Admin created...')
         create_admin(5832961437)
    james = fetch_UserData_table()
    print(james)
if __name__ == '__main__':
    main()